package com.example.labsheet2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    EditText fno,sno;
    Button Add,Sub;
    TextView tView;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fno = findViewById(R.id.text1);
        sno = findViewById(R.id.text2);
        Add = findViewById(R.id.buttonadd);
        Sub = findViewById(R.id.buttonsub);
        tView = findViewById(R.id.textView);


          Add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int n1 =Integer.parseInt(fno.getText().toString());
                    int n2 =Integer.parseInt(sno.getText().toString());
                    int ans;
                    ans = n1+n2;
                    tView.setText("Answer "+ans);

                }
            });
//
//
        Sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n1 =Integer.parseInt(fno.getText().toString());
                int n2 =Integer.parseInt(sno.getText().toString());
                int ans;
                ans = n1-n2;
                tView.setText("Answer = "+ans);

            }
        });
    }
}